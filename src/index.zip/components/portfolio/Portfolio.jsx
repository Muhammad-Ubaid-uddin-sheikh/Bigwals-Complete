import React from 'react'
import Layout from '../layout/Layout'
import BannerAll from '../bannerAll/Banner3dAnimation'
import gif from '../bannerAll/tna-dribbble-02-unscreen.gif'
import TabList from '../tabsList/TabList'
import { Facebook, Instagram, Twitter } from '@mui/icons-material'
import SportsBasketballIcon from '@mui/icons-material/SportsBasketball';
import './Portfolio.css'
import { useEffect } from 'react'
const Portfolio = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
   
        <Layout sx={{width:'100%',position:'relative'}}>
          {/* /////////////// social media icons ///////////////////// */}
          <div className='social-media-icons-div'><ul className='ul-social-div' data-aos="fade-left">
          <li className='social-li' id='social-links-drdder' >  <a href='https://www.facebook.com/bigwals?mibextid=LQQJ4d' target="_blank" id='icon-font-all-website' ><Facebook id='icon-social-edit'  style={{color: " #1877F2"}}/> &nbsp; &nbsp;FaceBook </a></li>
          <li className='social-li' id='social-links-drdder1'><a href='https://www.instagram.com/bigwalstudio/?igshid=YmMyMTA2M2Y%3D' target="_blank" id='icon-font-all-website' ><Instagram id='icon-social-edit'  style={{color: "#E4405F"}}/> &nbsp; &nbsp;Instagram</a></li>
          <li className='social-li' id='social-links-drdder2'><a href='https://twitter.com/bigwalstudio?s=11' target="_blank" id='icon-font-all-website' ><Twitter id='icon-social-edit'  style={{color: "#1da1f2"}}/> &nbsp; &nbsp;Twitter </a></li>
          <li className='social-li' id='social-links-drdder3'> <a href='https://dribbble.com/Bigwals' target="_blank" id='icon-font-all-website' > <SportsBasketballIcon style={{color: "#B2215A"}} id='icon-social-edit'/>  &nbsp; &nbsp;Dribbble </a>  </li>
          </ul></div>
    
           {/* /////////////// social media icons ///////////////////// */}
            <BannerAll paragraphText='Unleashing the Potential of Web Design: Explore Our Portfolio' titleMaina='Web Solutions Unleashing Creative Potential' gifSpace={gif }  />
      <div className="porfolio-main-d">
        <h1 className="appliatio-h20" id='h1-porfolio-edits'>
        Our <span className='gradient-text'> Portfolio </span>
        </h1>

        
      </div>
      <TabList/>
        </Layout>
      )
}

export default Portfolio