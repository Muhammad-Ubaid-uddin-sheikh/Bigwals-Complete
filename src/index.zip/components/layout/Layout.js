import React from 'react'
import '../../App.css'
 const Layout=({children})=>{
 
  return(
    <div className='layout' >
      <div className="fakeSnow">
    <div className="fake-snow-div-box">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
    {/* <Header /> */}
    {children}
    </div>
    </div>
  )
 
}
export default Layout
