import React from 'react'
import Layout from '../layout/Layout'
// import BannerAll from '../bannerAll/BannerDigital'
import gif from './images/digital-removebg-preview.png'
import AllColmFrontImg from './AllColmFrontImg'
// import AllColmFrontImgleft from './AllColmFrontImgleft'
import digital from '../bannerAll/about-removebg-preview.png'
import digitaltwo from '../bannerAll/Digital-Marketing-PNG-File.png'
import { Facebook, Instagram, Twitter } from '@mui/icons-material'
import SportsBasketballIcon from '@mui/icons-material/SportsBasketball';
import Colmdigital from '../colmdigital/Colmdigital'
import '../../styles/HeaderStyle.css'
import AccordinDigital from '../Accordin/AccordinDigital'
import { Button } from 'antd'
import { useEffect } from 'react'
import Appoinment from '../appoinment/Appoinment'
const DigitalMarketing = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <Layout sx={{width:'100%',position:'relative'}}>
      
      {/* /////////////// social media icons ///////////////////// */}
      <div className='social-media-icons-div'><ul className='ul-social-div' data-aos="fade-left">
      <li className='social-li' id='social-links-drdder' >  <a href='https://www.facebook.com/bigwals?mibextid=LQQJ4d' target="_blank" id='icon-font-all-website' ><Facebook id='icon-social-edit'  style={{color: " black"}}/> &nbsp; &nbsp;FaceBook </a></li>
      <li className='social-li' id='social-links-drdder1'><a href='https://www.instagram.com/bigwalstudio/?igshid=YmMyMTA2M2Y%3D' target="_blank" id='icon-font-all-website' ><Instagram id='icon-social-edit'  style={{color: "black"}}/> &nbsp; &nbsp;Instagram</a></li>
      <li className='social-li' id='social-links-drdder2'><a href='https://twitter.com/bigwalstudio?s=11' target="_blank" id='icon-font-all-website' ><Twitter id='icon-social-edit'  style={{color: "black"}}/> &nbsp; &nbsp;Twitter </a></li>
      <li className='social-li' id='social-links-drdder3'> <a href='https://dribbble.com/Bigwals' target="_blank" id='icon-font-all-website' > <SportsBasketballIcon style={{color: "black"}} id='icon-social-edit'/>  &nbsp; &nbsp;Dribbble </a>  </li>
      </ul></div>

       {/* /////////////// social media icons ///////////////////// */}
       <div style={{position:'relative'}}>
    <div className='banner-main-div'>
        <div className="row-banenr-all">
            <div className="colm-banner" data-aos ="fade-up"><div className="text-banner"><h4 className="banner-h4"  id='banner-h4' > 
            Best Digital Marketing Agency in the USA
</h4>
              <p className="banner-paragraph">

                We Bring Effective SEO and PPC Management to Your Business!                </p></div></div>
            <div className="colm-banner" data-aos ="fade-up"><div className="image-banner" id='image-digial-animation' ><img src={gif} alt="bannerimg" width="100%" /></div></div>
        </div>
    </div>
    </div>

    <AllColmFrontImg logoBrandingLogo={digital} firstpara= "WHO WE ARE?" h1heading="Online Marketing Service Provider" 
    againPara="BigWals is a top-rated social media marketing company in the USA, offering businesses to unlock their full potential via successful marketing campaigns. We offer the best digital marketing services to elevate your brand and meet the world!   "
  AgainagianP="  We at BigWals emphasize generating maximum ROI while making the most out of your budget. We know what it means to you, so our experts deliver the right consultancy!"
  thirdPara="Whether you are looking for digital marketing services for a small business or an enterprise, our experts have experience working with indies and fan-favorite brands. The results have made a difference for them!"

    
/>
<div className='main-caurosel-div' >
    <div className="row-carousle-main" >
       
      
       <div className="colm-caurosel"><p className='top-first-heading' style={{textAlign:'center'}}> WHAT DO WE OFFER?</p><h1 style={{textAlign:'center'}} className='com-h1-webiste-sec' >TRANSPARENT ADVERTISING</h1> <p className='paragrph-website-sec-p'>Ads, Just Ads. We do one thing - we do it with a monastic focus and better than anyone else. We are not for you if you want an online digital marketing company that offers the ultimate solution to everything but will not move the needle forward. We provide local internet marketing services that clearly show how much is spent, what is generated, and your net profit.</p>      </div>
       <div className="colm-caurosel" id='padding-id'><img src={digitaltwo} alt='logo' width='100%' /></div>
    </div>
   </div>
  <div className='heading-home-page'  data-aos ="fade-up">
  <div className='slider-shape slider-shape-two'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape02.png' /></div>
        <div className='slider-shape slider-shape-three'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape03.png' /></div>
  {/* <p className='top-first-heading'>OUR PORTFOLIO</p> */}
  <h1 className='sec-heading-home-page'>Digital Marketing Done Right!</h1>
  <p className='paragraph-content-home'>Why should you hire BigWals for your digital marketing needs? BigWals infuse technology and advertising together to upscale your business economically. Not only do we promise you a sustainable ROI, but we also increase your loyal consumers. Our expert digital marketers are ready to take your brand and shape it like the giants in the industry. Whether you are looking for a bounce back or to start from scratch, BigWals is always looking for an exciting journey!</p>
  </div>
    
<div className='third-sec-digital-sec-main'>
<div className='slider-shape slider-shape-two'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape02.png' /></div>
        <div className='slider-shape slider-shape-three'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape03.png' /></div>
  <div className='row-digital-sec-digital'>
   <div className='colmDigital-div-row-com' > <Colmdigital img1="https://grin.co/wp-content/uploads/2022/09/1-searchforinfluencers-at-2x.webp" headingFirst="Social Media Marketing" paragraph="Reaching your target audience is much easier than it used to be. However, getting them at the right time, need, and with amazing content is the name of the game. As one of the best social media marketing companies, we help you take it all. Let us help you effectively market your brand on social media platforms with enhanced engagement and fun!"/></div>
   <div className='colmDigital-div-row-com' > <Colmdigital img1="https://grin.co/wp-content/uploads/2022/05/Image_02_outreach@1x.webp" headingFirst="SEO and PPC Management" paragraph="Whether you rely solely on SEO, PPC, or both, BigWals offers transparent SEO and PPC management services. From optimizing your websites for search engine rankings to hitting the right audience with PPC, we bring specialized solutions. "/></div>
   <div className='colmDigital-div-row-com' ><Colmdigital img1="https://grin.co/wp-content/uploads/2022/09/1-allyourcontent-at-2x.webp  " headingFirst="Content Creation" paragraph="SEO, PPC, or anything content holds the crown in getting the audience in touch with you. Our content specialists are data-driven nerds – filled with creativity – ready to impress any target audience. As an online marketing service provider, we understand the intricacies of creating engaging content. With keen attention to your brand values, we deliver content that turns into cash."/></div> 
  </div>

  <div className='row-digital-sec-digital'>
   <div className='colmDigital-div-row-com' > <Colmdigital img1="https://grin.co/wp-content/uploads/2022/09/5-ensuretaxcompliance.webp" headingFirst="E-Mail Marketing" paragraph="E-mails have always been an essential factor in approaching consumers and clients. With powerful e-mail marketing strategies, you level up your sales quickly. We create personalized e-mails that do not irritate your audience and keep the spam folder at bay. Let us build you a subscriber list and use words for greater conversions!"/></div>
   <div className='colmDigital-div-row-com' > <Colmdigital img1="https://grin.co/wp-content/uploads/2022/09/ecommerece-at-2x.webp" headingFirst="Online Reputation Management" paragraph="People rely on either word of mouth or reviews and feedback a brand has. Our local internet marketing services help you get a reputable reputation in the digital world. We help you improve the game of reviews and feedback with promising tactics and utilize reputation management software."/></div>
   <div className='colmDigital-div-row-com' ><Colmdigital img1="	https://grin.co/wp-content/uploads/2022/09/reporting-analitics-at-2x.webp" headingFirst="Conversion Rate Optimization " paragraph="You can interact with tens of clients and buyers but one or two converts. What are you doing wrong? Let BigWals help you maintain impressive conversion rates with our best digital marketing services. We incorporate trending practices to reach your target audience, get leads, and convert them!"/></div> 
  </div>

  <div className="row-digital-sec-digital" style={{paddingBottom:'30px',paddingTop:'30px'}}>
  <div className='slider-shape slider-shape-two'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape02.png' /></div>
        <div className='slider-shape slider-shape-three'><img src = 'https://shtheme.org/demosd/pixer5/wp-content/themes/xotix/img/shape/slider_shape03.png' /></div>
<div className="com-contact-form" >
<h4 style={{    paddingBottom: '36px',lineHeight: '41px'}} className='com-h1-webiste-sec'>To Make Money, an Online Digital Marketing Company is Indispensable</h4> 
<p  className='paragrph-website-sec-p' >Talk about a flowing stream of cash – leverage digital marketing services for small businesses and enterprises. Your innovative idea has the potential to do wonders; the internet has the hold. Shift from traditional marketing to the new norm. Let BigWals close the gap and unleash your true potential with industry experts offering data-driven digital marketing services. </p> 
<p  className='paragrph-website-sec-p' >Besides, conventional advertising requires hustle and an excellent budget to operate. However, in this case, you can easily tap into a greater audience with fewer expenses. You can easily sustain a considerable ROI and maximize your growth with less time and resources. </p> 
<h4 style={{textAlign:'initial',fontSize:'18px'}} className='com-h1-webiste-sec'>Free 15-Minute Demo Call</h4>
<p  className='paragrph-website-sec-p' style={{textAlign:'initial',fontSize:'16px'}} >We will walk you through the plan to give you a clear understanding of what is happening with your business and what will happen next.</p>  
   </div>
   <div className="com-contact-form" >
   <div className="form-appoinment">
                <form  >
                <input name='Name' type="text" placeholder='Your Name' required className='appoinmment-input' onFocus='disable' />
                <input name='Email' type="Email" placeholder='Your Email' required className='appoinmment-input' />
                <input name='Phone-Number' type="number" placeholder='Phone' required className='appoinmment-input'/>
                <input name='Text' type="text" placeholder='Service Your Required' required className='appoinmment-input'  />
                <textarea id='textarea-appoimnet' className='appoinmment-input' rows={3} placeholder='Message' />
                <Button type='submit' id='button-Appoinmet'>Send Message</Button>
                </form>
            </div>
</div></div>

</div>
<Appoinment/>
<AccordinDigital/>

    </Layout>
  )
}

export default DigitalMarketing