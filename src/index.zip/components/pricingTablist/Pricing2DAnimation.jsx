import React from 'react'
import './PricingTablist.css'
import PricingBox from '../pricingBox/PricingBox'
import PricingTagBox from '../pricingBox/PricingTagBox'
// import CorporateFareIcon from '@mui/icons-material/CorporateFare';
import TwoWheelerIcon from '@mui/icons-material/TwoWheeler';
import BusinessCenterIcon from '@mui/icons-material/BusinessCenter';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import PedalBikeIcon from '@mui/icons-material/PedalBike';
import 'aos/dist/aos.css'

const Pricing2DAnimation = () => {
    return (
        <div>
             <div className="main-tablist-pricing">
            <div className="row-pricing-tablsit"   data-aos ='fade-up'>
            <PricingBox  
            logo1= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            logo2= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            logo3= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo4= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo5= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo6= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo7= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo8= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo9= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             MainLogoFirst={<PedalBikeIcon id='pedal-bike-pricing' />} 
             title='2D Design/Character'
             price='$120.00'
             previousPrice='$150.00'
             category1= '- Business Card'
             category2= '- Letterheads'
             category3= '- Envelope'
             category4= '- 24-48 H Delivery'
            //  category4= ''
            //  category5= ''
            //  category6= ''
            //   category7= ''
            //    category8= ''
            //    category9= ''
            //    category10= '- JPG, PDF, PNG'
    
            />
            
            <PricingBox  
             logo1= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo2= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo3= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo4= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            //  logo5= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            //  logo6= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            //  logo7= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            //  logo8= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            //  logo9= {<CheckCircleIcon id='icon-checkcircle-price'/>}
              logo= {<CheckCircleIcon id='icon-checkcircle-price'/>}
              MainLogoFirst={<TwoWheelerIcon id='pedal-bike-pricing' />} 
              title='2D Whiteboard Animation'
              price='$399.00'
              previousPrice='$159.00'
              category1= '- Script'
              category2= '- Storyboard & Characters'
              category3= '- Voiceover'
              category4= '- Animation & SFX'
              category5= '- Finalized & Published'
              




              // category6= '- HQ PNG + JPEG'
              //  category7= '- 100% Ownership'
              //   category8= '- JPG, PDF, PNG'
              //   category9= '- JPG, PDF, PNG'
              //   category10= '- JPG, PDF, PNG'
                 />
            <PricingTagBox 
            
            logo1= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            logo2= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            logo3= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            logo4= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo5= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo6= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo7= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo8= {<CheckCircleIcon id='icon-checkcircle-price'/>}
            // logo9= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             MainLogoFirst={<BusinessCenterIcon id='pedal-bike-pricing' />} 
             title='Custom 2D Animation'
             price='$499.00'
             previousPrice='$219.00'
             category1= '- Storyboard & Characters'
             category2= '- Letterhead'
             category3= '- Voiceover'
             category4= '- Finalized & Published'
             category5= '-  Script'
            //   category6= '- Email Signature'
            //     category7= '- 24-48 H Delivery'
            //     category8= '- Web Banner'
               




                // category9= '- 100% OwnerShip'
                // category10= '- JPG, PDF, PNG , EPS'
                />
    
    
            <PricingBox 
             logo1= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo2= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo3= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             logo4= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             // logo5= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             // logo6= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             // logo7= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             // logo8= {<CheckCircleIcon id='icon-checkcircle-price'/>}
             // logo9= {<CheckCircleIcon id='icon-checkcircle-price'/>}
              logo= {<CheckCircleIcon id='icon-checkcircle-price'/>}
              MainLogoFirst={<BusinessCenterIcon id='pedal-bike-pricing' />} 
              title=' Motion Graphics'
              price='$499.00'
              previousPrice='$219.00'
              category1= '- Storyboard & Characters'
              category2= '- Letterhead'
              category3= '- Voiceover'
              category4= '- Finalized & Published'
              category5= '-  Script'
                />
            </div>
           </div>
        </div>
      )
}

export default Pricing2DAnimation