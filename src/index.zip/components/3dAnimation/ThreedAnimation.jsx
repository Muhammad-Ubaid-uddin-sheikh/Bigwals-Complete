import React from 'react'
import animation from './3dnewiamges4.jpeg'
import animation1 from './GIF (1).gif'
import animation2 from '../2dAnimation/3danimation2.jpeg'
import animation3 from '../2dAnimation/3danimation3.jpeg'
import animation4 from '../2dAnimation/3danimation4.jpeg'
import animation5 from '../2dAnimation/3danimation5.jpeg'
import animation6 from '../2dAnimation/3danimation6.jpeg'
import animation7 from '../2dAnimation/3danimation7.jpeg'
import animation8 from '../2dAnimation/3danimation8.jpeg'
import animation9 from './3dnewiamges1.jpeg'
import animation10 from './3danimationnewimages2.png'
import animation11 from './3danimationnewimages3.jpg'
import animation12 from './3danimationnewimages4.jpeg'
import animation13 from './3dnewiamges2.jpeg'
import animation14 from './3danimationnewimages6.jpg'
import animation15 from './3dnewiamges3.jpeg'
import '../2dAnimation/2dAnimation.css'
import 'aos/dist/aos.css'
const ThreedAnimation = () => {
  return (
    <div className="porfolio-2d-animation-main">
    <div className="rw0-2d-animation" data-aos ="zoom-in-up">
        <div className="images-2d-animation"><img src={animation} alt="" srcset="" width='100%'  height="100%"/></div>
        <div className="images-2d-animation"><img src={animation1} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation2} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation3} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation4} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation5} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation6} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation7} alt="" srcset="" width='100%'   height="100%" /></div>
        <div className="images-2d-animation"><img src={animation8} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation9} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation10} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation11} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation12} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation13} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation14} alt="" srcset="" width='100%'  height="100%" /></div>
        <div className="images-2d-animation"><img src={animation15} alt="" srcset="" width='100%'  height="100%" /></div>
      
    </div>
</div>
  )
}

export default ThreedAnimation