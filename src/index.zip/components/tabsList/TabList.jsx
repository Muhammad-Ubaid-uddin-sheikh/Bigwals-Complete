import * as React from 'react';
import './TabList.css'
import TwodAnimation from '../cards/TwodAnimation';
import CoursesCard from '../cards/CoursesCards';
import AllCardImgs from '../cards/AllCardImgs';
import BrandingTablist from '../cards/BrandingTablist';
import LogoImg from '../cards/LogoImg';
import ThreedAnimation from '../3dAnimation/ThreedAnimation';
import Taba from 'react-bootstrap/Tab';
import Tabsaa from 'react-bootstrap/Tabs';
function TabPanel() {
//   const { children, value, index, ...other } = props;

//   return (
//     <div
//       role="tabpanel"
//       hidden={value !== index}
//       id={`simple-tabpanel-${index}`}
//       aria-labelledby={`simple-tab-${index}`}
//       {...other}
//     >
//       {value === index && (
//         <Box sx={{ p: 3 }}>
//           <Typography>{children}</Typography>
//         </Box>
//       )}
//     </div>
//   );
// }

// TabPanel.propTypes = {
//   children: PropTypes.node,
//   index: PropTypes.number.isRequired,
//   value: PropTypes.number.isRequired,
// };

// function a11yProps(index) {
//   return {
//     id: `simple-tab-${index}`,
//     'aria-controls': `simple-tabpanel-${index}`,
//   };
// }

// export default function BasicTabs() {
//   const [value, setValue] = React.useState(0);

//   const handleChange = (event, newValue) => {
//     setValue(newValue);
//   };

  return (
    <div className="tablisst">


<Tabsaa
      defaultActiveKey="all"
      transition={false}
      id="noanim-tab-example"
      className="mb-3"
    >
      <Taba  eventKey="all" title="All" >
      <AllCardImgs/>
      </Taba>
      <Taba eventKey="Logo" title="Logo">
      <LogoImg/>
      </Taba>
      <Taba eventKey="Website" title="Website" >
       <CoursesCard/>
      </Taba>
      <Taba eventKey="Branding" title="Branding" >
      <BrandingTablist/>
      </Taba>
      <Taba eventKey="2D Animation" title="2D Animation" >
      <TwodAnimation/>
      </Taba>
      <Taba eventKey="3D Animation" title="3D Animation" >
      <ThreedAnimation/>
      </Taba>
    </Tabsaa>
  

    {/* <Box sx={{ width: '100%' }} id='tabs-Block'>  
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs id='tabs-Block' value={value} onChange={handleChange} aria-label="basic tabs example">
          <Tab label="All"  {...a11yProps(0)} />
          <Tab label="Logo" id='tabsaa-Block' {...a11yProps(1)} />
          <Tab label="Website" id='tabs-Block' {...a11yProps(2)} />
          <Tab label="Branding"  {...a11yProps(3)} />
          <Tab label="2D Animation"  {...a11yProps(4)} />
          <Tab label="3D Animation"  {...a11yProps(5)} />
        </Tabs>
      </Box>
      <TabPanel value={value} index={0}>
       <AllCardImgs/>
      </TabPanel>
      <TabPanel value={value} index={1}>
       <LogoImg/>
      </TabPanel>
      <TabPanel value={value} index={2}>
        <CoursesCard/>
      </TabPanel>
      <TabPanel value={value} index={3}>
        <BrandingTablist/>
      </TabPanel>
      <TabPanel value={value} index={4}>
       <TwodAnimation/>
      </TabPanel>
      <TabPanel value={value} index={5}>
        <ThreedAnimation/>
      </TabPanel>
    </Box> */}
    </div>
  );
}
export default TabPanel