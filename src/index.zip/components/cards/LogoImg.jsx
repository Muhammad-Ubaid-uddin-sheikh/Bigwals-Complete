import card from './ImagesAllCard/RLOGONEW2.png'
import card7 from './ImagesAllCard/logonew2.webp'
import card1 from './ImagesAllCard/logonew13.webp'
import card2 from './ImagesAllCard/logonew12.webp'
import card3 from './ImagesAllCard/logonew1.webp'
import card4 from './ImagesAllCard/logonew4.webp'
import card5 from './ImagesAllCard/logonew5.webp'
import card6 from './ImagesAllCard/logonew6.webp'
import card8 from './ImagesAllCard/logonew7webp.webp'
import card10 from './ImagesAllCard/logonew8.webp'
import card12 from './ImagesAllCard/logonew9.webp'
import card13 from './ImagesAllCard/RLOGONEW1.jpg'
import card14 from './ImagesAllCard/logonew11.webp'
import card15 from './ImagesAllCard/logosnew.webp'
import card16 from './ImagesAllCard/logonew3.webp'
import card17 from './ImagesAllCard/logonew2.webp'

import MediaCard from './MediaCard'
import './AllStyle.css';
const Logo = () => {
  return (
    <div className="main-media-div" >
<MediaCard
img1 = {card7} 
img2={card3}
img3={card4}
img4={card16}
img5={card14}
img6={card2}
img7={card6}
img8={card10}
img9={card8}
img10={card15}
img11={card17}
img12={card12}
img13={card}
img14={card1}
img15={card5}
img16={card13} 

/>
</div>
    
  )
}

export default Logo