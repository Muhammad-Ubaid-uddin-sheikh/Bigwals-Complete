import React from 'react'
import card from './ImagesAllCard/brandingIMG1.jpeg'
import card1 from './ImagesAllCard/brandingIMG2.jpeg'
import card2 from './ImagesAllCard/brandingIMG3.jpeg'
import card3 from './ImagesAllCard/brandingIMG4.jpeg'
import card4 from './ImagesAllCard/logonew1.webp'
import card5 from './ImagesAllCard/logonew2.webp'
import card6 from './ImagesAllCard/logonew3.webp'
import card8 from './ImagesAllCard/logonew4.webp'
import card10 from './ImagesAllCard/webiste2.jpg'
import card12 from './ImagesAllCard/webiste3.jpeg'
import card13 from './ImagesAllCard/webiste4.jpeg'
import card14 from './ImagesAllCard/brandingIMG8.jpeg'
import card15 from './ImagesAllCard/logonew11.webp'
import card16 from './ImagesAllCard/RLOGONEW1.jpg'
import card17 from './ImagesAllCard/brandingIMG9.jpeg'
import MediaCard from './MediaCard'
import './AllStyle.css';
const BrandingTablist = () => {
  return (
    <div>
        <MediaCard
img1 = {card13} 
img2={card3}
img3={card4}
img4={card16}
img5={card14}
img6={card2}
img7={card6}
img8={card10}
img9={card8}
img10={card15}
img11={card17}
img12={card12}
img13={card}
img14={card1}
img15={card5}
img16={card13} 

/>
    </div>
  )
}

export default BrandingTablist