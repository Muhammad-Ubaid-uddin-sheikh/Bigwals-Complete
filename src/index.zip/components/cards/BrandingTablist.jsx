import React from 'react'
import card from './ImagesAllCard/brandingIMG1.jpeg'
import card1 from './ImagesAllCard/brandingIMG2.jpeg'
import card2 from './ImagesAllCard/brandingIMG3.jpeg'
import card3 from './ImagesAllCard/brandingIMG4.jpeg'
import card4 from './ImagesAllCard/brandingIMG5.jpeg'
import card5 from './ImagesAllCard/brandingIMG6.jpeg'
import card6 from './ImagesAllCard/brandingIMG7.jpg'
import card8 from './ImagesAllCard/brandingIMG8.jpeg'
import card10 from './ImagesAllCard/brandingIMG9.jpeg'
import card12 from './ImagesAllCard/brandingIMG10.jpeg'
import card13 from './ImagesAllCard/brandingNewwwhat1.jpeg'
import card14 from './ImagesAllCard/brandingNewwwhat2.jpeg'
import card15 from './ImagesAllCard/brandingNewwwhat3.jpeg'
import card16 from './ImagesAllCard/brandingNewwwhat4.jpeg'
import card17 from './ImagesAllCard/brandingNewwwhat5.jpeg'
import MediaCard from './MediaCard'
import './AllStyle.css';
const BrandingTablist = () => {
  return (
    <div>
        <MediaCard
img1 = {card13} 
img2={card3}
img3={card4}
img4={card16}
img5={card14}
img6={card2}
img7={card6}
img8={card10}
img9={card8}
img10={card15}
img11={card17}
img12={card12}
img13={card}
img14={card1}
img15={card5}
img16={card13} 

/>
    </div>
  )
}

export default BrandingTablist