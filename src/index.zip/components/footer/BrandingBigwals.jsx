import React from 'react'
import './Footer.css'
const BrandingBigwals = () => {
  return (
    <div>
        <div className="branding-big" >
    <div className="row-branding">
        <div className="colm-branding-big"><p>© 2023, BigWals.</p></div>
        <div className="colm-branding-big"><p style={{textAlign:'end'}}>All right reserved.</p></div>
    </div>
   </div>
    </div>
  )
}

export default BrandingBigwals